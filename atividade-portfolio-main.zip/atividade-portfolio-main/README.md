# Modelo de Mini Portfólio Pessoal

Este repositório vai te guiar na construção de um **mini portfólio pessoal** em HTML + CSS.  
Ele está dividido em **etapas de progressão**, para que você acompanhe passo a passo.  

**Dica**: Não copie tudo de uma vez. Vá etapa por etapa, assim você entende melhor o processo.  

---

## Etapas

### Passo 1 – Estrutura básica
Crie um arquivo `index.html`:

Adicione o código da pasta [passo1](/pasta1/).