# Passo 1 - Criar estrutura da página
Siga os seguintes passos:
* Crie um arquivo chamado ´index.html´
* Vá até o arquivo [index.html](/pasta1/index.html), copie e cole o código no que você criou
* Abra o seu arquivo ´index.html´ no navegador
* Vá para o [passo2](/pasta2/)
