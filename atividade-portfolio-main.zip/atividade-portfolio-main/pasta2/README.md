# Passo 2 - Adicionar elementos na página
Siga os seguintes passos:
* abra o arquivo ´index.html´ do passo anterior
* Vá até o arquivo [index.html](/pasta2/index.html), copie e cole o código no arquivo que você criou
* Abra o seu arquivo ´index.html´ no navegador
* Vá para o [passo 3](/pasta3/)
