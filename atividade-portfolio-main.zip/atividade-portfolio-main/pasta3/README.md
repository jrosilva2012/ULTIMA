# Passo 3 - Adicionar estilos na página
Siga os seguintes passos:
* Crie um arquivo chamado ´style.css´
* Vá até o arquivo [style.css](/pasta3/style.css), copie e cole o código no que arquivo você criou
* Abra o seu arquivo ´index.html´ no navegador
* Vá para o [passo 4](/pasta4/)
