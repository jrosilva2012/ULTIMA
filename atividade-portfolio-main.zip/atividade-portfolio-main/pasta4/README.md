# Passo 4 - Página finalizada e extras
Se você chegou até aqui, pode comparar a página que você criou nos passos anteriores, com a página completa [aqui](/pasta4/)
## Desafio
* Mude as cores e fontes
* Crie 3 cards contendo projetos que você já fez (utilize os mesmos cards de aulas anteriores)
